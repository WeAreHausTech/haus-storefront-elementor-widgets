export type { CustomWidgetProps } from './widgets-renderer.tsx'
export { WidgetsRenderer } from './widgets-renderer'
export { bootstrapWidget } from './bootstrap-widget'